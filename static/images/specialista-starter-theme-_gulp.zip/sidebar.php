<div class="sidebar mt-5 mt-lg-0">
	<?php
	if (is_active_sidebar('sidebar1')) :

		dynamic_sidebar('sidebar1');

	endif;
	?>
</div>